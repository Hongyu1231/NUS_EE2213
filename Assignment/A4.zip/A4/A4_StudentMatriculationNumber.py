from sympy import symbols, And, Not, Or, Implies, Equivalent
from sympy.logic.boolalg import truth_table

# Please replace "StudentMatriculationNumber" with your actual matric number here and in the filename
def A4_StudentMatriculationNumber(query):
    """
    Args:
        query: A sympy logical expression representing the query to be checked
               (e.g., A, Not(B), etc.).

    Returns:
        result: A string "True" if the query is a Knight;
                A string "False" if the query is a Knave;
                A string "Not Sure" if the type of the query cannot be determined.
    """

    # your code goes here


    # return in this order
    return result


