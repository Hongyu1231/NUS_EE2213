import numpy as np


# Please replace "MatricNumber" with your actual matric number here and in the filename
def A1_MatricNumber(x, y):
    """
    Input type
    :x type: numpy.ndarray
    :y type: numpy.ndarray

    Return type
    :euclidean_dist type: numpy.ndarray
    :manhattan_dist type: numpy.ndarray
   
    """

    # your code goes here
    pass

    # return in this order
    return euclidean_dist, manhattan_dist


